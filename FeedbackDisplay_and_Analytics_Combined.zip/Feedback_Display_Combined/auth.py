import getpass

def login(cursor, role):
    user_id = input("Enter your UserID: ")
    password = getpass.getpass("Enter your password: ")
    role = role.lower()

    query = "SELECT * FROM faculty WHERE id = %s AND password = %s"
    if role not in ["faculty", "admin"]:
        print("Invalid role! Try again.")
        return None, None

    cursor.execute(query, (user_id, password))
    user = cursor.fetchone()

    if user:
        print(f"\nLogin successful as {role.upper()}!\n")
        return user_id, role
    else:
        print("\nInvalid credentials! Try again.\n")
        return None, None

def signup(cursor, db, role):
    print("\nSIGNUP")
    user_id = input("Enter your UserID: ")
    name = input("Enter your name: ")
    password = getpass.getpass("Enter your password: ")
    role = role.lower()

    if role not in ["faculty", "admin"]:
        print("Invalid role! Try again.")
        return

    check_query = "SELECT id FROM faculty WHERE id = %s"
    cursor.execute(check_query, (user_id,))
    if cursor.fetchone():
        print("\nUser ID already exists! Please log in instead.\n")
        return

    query = "INSERT INTO faculty (id, name, password, role) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (user_id, name, password, role))
    db.commit()

    print("\nSignup successful! You can now log in.\n")
