import mysql.connector
import getpass
from auth import (login, signup)


def get_feedback_and_analytics(role):

    try:
        # Connect to MySQL Database
        conn = mysql.connector.connect(
            host="localhost",
            user="root",  
            password="toothless1234",  
            database="microservices"  
        )
        cursor = conn.cursor()

        if role == "student":
            stu_id = input("Enter Student ID : ")
            print("\nFeedback Received :")
            cursor.execute("SELECT feedback_given_by_prof, time_of_feed_prof FROM prof_feedback WHERE stu_id = %s", (stu_id,))
            feedbacks = cursor.fetchall()
            if feedbacks:
                for feedback in feedbacks:
                    print(f"- {feedback[0]} (Time: {feedback[1]})")
            else:
                print("No feedback to display.")

            print("\nFeedback Given :")
            cursor.execute("SELECT prof_id, feedback_given_by_student, time_of_feed_stu FROM stu_feedback WHERE stu_id = %s", (stu_id,))
            feedbacks = cursor.fetchall()
            if feedbacks:
                for feedback in feedbacks:
                    print(f"- {feedback[1]} (Time: {feedback[2]})")
            else:
                print("No feedback has been given yet.")

        elif role == "faculty":
            while True:
                print("\nWelcome to the Feedback System")
                print("1️. Signup")
                print("2️. Login")
                print("3️. Exit")
                
                option = input("\nEnter your choice : ")

                if option == "1":
                    signup(cursor, conn, role)
                elif option == "2":
                    faculty_id, role = login(cursor, role)
                    if faculty_id:
                        break
                elif option == "3":
                    print("\nGoodbye!\n")
                    cursor.close()
                    conn.close()
                    exit()
                else:
                    print("Invalid choice! Try again.")

            while True:
                print("\nFeedback System Menu")
                print("1️. View Feedback")
                print("2️. Logout")

                choice = input("\nEnter your choice : ")

                if choice == "1":
                    prof_id = input("Enter Faculty ID : ")
                    print("\nFeedback received:")
                    cursor.execute("SELECT feedback_given_by_student, time_of_feed_stu FROM stu_feedback WHERE prof_id = %s", (prof_id,))
                    feedbacks = cursor.fetchall()
                    if feedbacks:
                        for feedback in feedbacks:
                            print(f"- {feedback[0]} (Time: {feedback[1]})")
                    else:
                        print("No feedback to display.")

                    print("\nFeedback Given :")
                    cursor.execute("SELECT stu_id, feedback_given_by_prof, time_of_feed_prof FROM prof_feedback WHERE prof_id = %s", (prof_id,))
                    feedbacks = cursor.fetchall()
                    if feedbacks:
                        for feedback in feedbacks:
                            print(f"- For SRN {feedback[0]}: {feedback[1]} (Time: {feedback[2]})")
                    else:
                        print("No feedback has been given yet.")
                elif choice == "2":
                        print("\nLogging out... Thank you!\n")
                        break
                else:
                        print("Invalid choice! Try again.")

        elif role == "admin":
            while True:
                print("\nWelcome to the Feedback System")
                print("1️. Signup")
                print("2️. Login")
                print("3️. Exit")
                
                option = input("\nEnter your choice : ")

                if option == "1":
                    signup(cursor, conn, role)
                elif option == "2":
                    faculty_id, role = login(cursor, role)
                    if faculty_id:
                        break
                elif option == "3":
                    print("\nGoodbye!\n")
                    cursor.close()
                    conn.close()
                    exit()
                else:
                    print("Invalid choice! Try again.")

            while True:
                print("1️. View All Feedback")
                print("2️. Feedback Count by Course")
                print("3️. Feedback Count by Faculty")
                print("4️. Top 5 Courses with Most Feedback")
                print("5️. Courses with Least Feedback")
                print("6️. Top 5 Most Active Faculty")
                print("7️. Recent 10 Feedback Entries")
                print("8️. Logout")

                choice = input("\nEnter your choice : ")

                if choice == "1":
                    query = "SELECT faculty_id, course_id, feedback_text, timestamp FROM course_feedback ORDER BY timestamp DESC"
                    cursor.execute(query)
                    feedbacks = cursor.fetchall()
                    print("\nAll Feedbacks:\n")
                    for feedback in feedbacks:
                        print(f"Faculty ID: {feedback[0]}, Course ID: {feedback[1]}, Feedback: {feedback[2]}, Submitted At: {feedback[3]}")
                    print("\n")

                elif choice == "2":
                    query = "SELECT course_id, COUNT(*) FROM course_feedback GROUP BY course_id"
                    cursor.execute(query)
                    results = cursor.fetchall()
                    print("\nFeedback Count by Course:")
                    for row in results:
                        print(f"Course ID: {row[0]}, Feedback Count: {row[1]}")
                    print("\n")
                elif choice == "3":
                    query = "SELECT faculty_id, COUNT(*) FROM course_feedback GROUP BY faculty_id"
                    cursor.execute(query)
                    results = cursor.fetchall()
                    print("\nFeedback Count by Faculty:")
                    for row in results:
                        print(f"Faculty ID: {row[0]}, Feedback Count: {row[1]}")
                    print("\n")
                elif choice == "4":
                    query = "SELECT course_id, COUNT(*) AS feedback_count FROM course_feedback GROUP BY course_id ORDER BY feedback_count DESC LIMIT 5"
                    cursor.execute(query)
                    results = cursor.fetchall()
                    print("\nTop 5 Courses with Most Feedback:")
                    for row in results:
                        print(f"Course ID: {row[0]}, Feedback Count: {row[1]}")
                    print("\n")
                elif choice == "5":
                    query = "SELECT course_id, COUNT(*) AS feedback_count FROM course_feedback GROUP BY course_id ORDER BY feedback_count ASC LIMIT 5"
                    cursor.execute(query)
                    results = cursor.fetchall()
                    print("\nCourses with Least Feedback:")
                    for row in results:
                        print(f"Course ID: {row[0]}, Feedback Count: {row[1]}")
                    print("\n")
                elif choice == "6":
                    query = "SELECT faculty_id, COUNT(*) FROM course_feedback GROUP BY faculty_id ORDER BY COUNT(*) DESC LIMIT 5"
                    cursor.execute(query)
                    results = cursor.fetchall()
                    print("\nTop 5 Most Active Faculty Members:")
                    for row in results:
                        print(f"Faculty ID: {row[0]}, Feedback Count: {row[1]}")
                    print("\n")
                elif choice == "7":
                    query = "SELECT faculty_id, course_id, feedback_text, timestamp FROM course_feedback ORDER BY timestamp DESC LIMIT 10"
                    cursor.execute(query)
                    results = cursor.fetchall()
                    print("\nRecent 10 Feedbacks:")
                    for row in results:
                        print(f"Faculty ID: {row[0]}, Course ID: {row[1]}, Feedback: {row[2]}, Submitted At: {row[3]}")
                    print("\n")
                elif choice == "8":
                    print("\nLogging out... Thank you!\n")
                    break
                else:
                    print("Invalid choice! Try again.")

        else:
            print("\nInvalid Role...Try Again!")

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

    finally:
        cursor.close()
        conn.close()

