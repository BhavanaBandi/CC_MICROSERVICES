from combined_feed_and_analytics import get_feedback_and_analytics


def main():

    while True:
        print("\nFeedback System")
        print("1. Display Feedback and Analytics")
        print("2. Exit")

        choice = input("Enter your choice : ")

        if choice == "1":
            role = input("\nEnter your role (student/faculty/admin) : ")
            role = role.lower()
            get_feedback_and_analytics(role)

        elif choice == "2":
            print("\nExiting... Thank you!\n")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()